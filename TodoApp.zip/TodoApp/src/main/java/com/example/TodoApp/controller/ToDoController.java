package com.example.TodoApp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.TodoApp.service.ToDoService;

@Controller
public class ToDoController {

	@Autowired
	private ToDoService service;
	
	@GetMapping("/ViewToDoList")
	private String viewAllToDoitems(Model model) {
		model.addAttribute("list", service.getAllToDoItems());
		
		return "ViewToDoList";
	}
	@PostMapping
	private String updateToDoStatus() {
		
	}
	@GetMapping
	private String addToDoItem() {
	
	}
	@PostMapping
	private String saveToDoItem() {
		
	}
	@GetMapping
	private String editToDoitems() {
		
	}
	
	@PostMapping
	private String editSaveToDoitems() {
		
	}
}
